Grafics: https://pixel-boy.itch.io/ninja-adventure-asset-pack
