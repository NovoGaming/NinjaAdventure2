package com.demoncube.ninjaadventure.game.enviroment;

public class Map {

    public Map (int mapId) {

    }
}
