package com.demoncube.ninjaadventure.game.helpers.customVariables;

public class vector {
    public double x, y;

    public vector(double x, double y) {
        this.x = x;
        this.y = y;
    }
}
