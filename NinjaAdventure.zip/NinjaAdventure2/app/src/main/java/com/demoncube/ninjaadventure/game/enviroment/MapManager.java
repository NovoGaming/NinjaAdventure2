package com.demoncube.ninjaadventure.game.enviroment;

import android.graphics.Canvas;
import android.graphics.PointF;

public class MapManager {


    public void render(Canvas c, PointF camera){

    }

}
